﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab6
{

    public partial class Form1 : Form
    {
        Bitmap bitmap;

        int[] RED = new int[256];
        int[] GREEN = new int[256];
        int[] BLUE = new int[256];

        bool read = false;


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog Opfile = new OpenFileDialog();
            if (DialogResult.OK == Opfile.ShowDialog())
            {
                this.pictureBox1.Image = new Bitmap(Opfile.FileName);
                bitmap = (Bitmap)this.pictureBox1.Image;

                Array.Clear(RED, 0, RED.Length);
                Array.Clear(GREEN, 0, GREEN.Length);
                Array.Clear(BLUE, 0, BLUE.Length);


                histogram();
                
                read = true;
                panel1.Invalidate();
                panel2.Invalidate();
                panel3.Invalidate();
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            Bitmap bitmapEdited = (Bitmap)bitmap.Clone();


            int width = pictureBox1.Image.Width;
            int height = pictureBox1.Image.Height;

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Color cA = bitmapEdited.GetPixel(x, y);

                    double r = (double)cA.R;
                    double g = (double)cA.G;
                    double b = (double)cA.B;

                    double r1, g1, b1;
                    r1 = (127 + trackBar1.Value) * r;
                    r1 = r1 / 127;

                    r1 = r1 - trackBar1.Value;

                    g1 = (127 + trackBar1.Value) * g;
                    g1 = g1 / 127;

                    g1 = g1 - trackBar1.Value;

                    b1 = (127 + trackBar1.Value) * b;
                    b1 = b1 / 127;

                    b1 = b1 - trackBar1.Value;


                    bitmapEdited.SetPixel(x, y, Color.FromArgb((int)r1, (int)g1, (int)b1));
                }
            }

            pictureBox1.Image = bitmapEdited;
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            Bitmap bitmapEdited = (Bitmap)bitmap.Clone();


            int width = pictureBox1.Image.Width;
            int height = pictureBox1.Image.Height;

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Color cA = bitmapEdited.GetPixel(x, y);

                    int r = cA.R;
                    int g = cA.G;
                    int b = cA.B;


                    r = (127 / (127 - trackBar2.Value)) * (r - trackBar2.Value);
                    g = (127 / (127 - trackBar2.Value)) * (g - trackBar2.Value);
                    b = (127 / (127 - trackBar2.Value)) * (b - trackBar2.Value);

                    if (r < 0)
                    {
                        r = 0;
                    }
                    if (g < 0)
                    {
                        g = 0;
                    }
                    if (b < 0)
                    {
                        b = 0;
                    }
                    if (r > 255)
                    {
                        r = 255;
                    }
                    if (g > 255)
                    {
                        g = 255;
                    }
                    if (b > 255)
                    {
                        b = 255;
                    }


                    bitmapEdited.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }

            pictureBox1.Image = bitmapEdited;
        }

        


        private void histogram()
        {
            int width = pictureBox1.Image.Width;
            int height = pictureBox1.Image.Height;

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Color cA = bitmap.GetPixel(x, y);

                    int r = cA.R;
                    int g = cA.G;
                    int b = cA.B;

                    RED[r]++;
                    GREEN[g]++;
                    BLUE[b]++;
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            if(read == true)
            {
                Graphics graphR = e.Graphics;
                
                for (int i = 0; i < 256; i++)
                {
                    float r = RED[i];

                    r = r / (pictureBox1.Image.Height * pictureBox1.Image.Width);
                    r *= 6000;

                    graphR.DrawLine(new Pen(Color.Red), i, panel1.Height, i, panel1.Height - r);
                }
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            if (read == true)
            {
                Graphics graphR = e.Graphics;

                for (int i = 0; i < 256; i++)
                {
                    float r = GREEN[i];

                    r = r / (pictureBox1.Image.Height * pictureBox1.Image.Width);
                    r *= 6000;

                    graphR.DrawLine(new Pen(Color.Green), i, panel1.Height, i, panel1.Height - r);
                }
            }
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            if (read == true)
            {
                Graphics graphR = e.Graphics;

                for (int i = 0; i < 256; i++)
                {
                    float r = BLUE[i];

                    r = r / (pictureBox1.Image.Height * pictureBox1.Image.Width);
                    r *= 6000;

                    graphR.DrawLine(new Pen(Color.Blue), i, panel1.Height, i, panel1.Height - r);
                }
            }
        }
    }
}
